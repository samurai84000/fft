import uvm_pkg::*;

class my_uvm_transaction extends uvm_sequence_item;

    logic [31:0]        in_data;    // one pixel word (Q0, 0-255)
    logic [3:0]         out_class;  // predicted digit 0-9 (monitor fills this)
    logic signed [31:0] out_val;    // max activation value (monitor fills this)

    function new(string name = "");
        super.new(name);
        in_data   = '0;
        out_class = '0;
        out_val   = '0;
    endfunction

    `uvm_object_utils_begin(my_uvm_transaction)
        `uvm_field_int(in_data,   UVM_ALL_ON)
        `uvm_field_int(out_class, UVM_ALL_ON)
        `uvm_field_int(out_val,   UVM_ALL_ON)
    `uvm_object_utils_end

endclass


class my_uvm_sequence extends uvm_sequence#(my_uvm_transaction);
    `uvm_object_utils(my_uvm_sequence)

    function new(string name = "");
        super.new(name);
    endfunction

    task body();
        my_uvm_transaction tx;
        int fd;
        int nread;
        int unsigned pixel_u;
        int i;

        `uvm_info("SEQ_RUN",
                  $sformatf("Loading %0d pixels from %s ...", NUM_INPUTS, NN_IN_NAME),
                  UVM_LOW);

        fd = $fopen(NN_IN_NAME, "r");
        $display("CWD check - fopen returned: %0d", fd);
        if (!fd) `uvm_fatal("SEQ_RUN", $sformatf("Failed to open %s", NN_IN_NAME));

        i = 0;
        while ((i < NUM_INPUTS) && !$feof(fd)) begin
            nread = $fscanf(fd, "%h\n", pixel_u);
            if (nread != 1) break;

            tx = my_uvm_transaction::type_id::create(.name("tx"), .contxt(get_full_name()));
            start_item(tx);
            tx.in_data = pixel_u[31:0];
            finish_item(tx);

            i++;
        end

        $fclose(fd);
        `uvm_info("SEQ_RUN", $sformatf("Input load complete. pixels=%0d", i), UVM_LOW);
    endtask

endclass


typedef uvm_sequencer#(my_uvm_transaction) my_uvm_sequencer;
