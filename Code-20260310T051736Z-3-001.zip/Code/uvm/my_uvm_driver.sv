import uvm_pkg::*;

class my_uvm_driver extends uvm_driver#(my_uvm_transaction);

    `uvm_component_utils(my_uvm_driver)

    virtual my_uvm_if vif;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        void'(uvm_resource_db#(virtual my_uvm_if)::read_by_name(
            .scope("ifs"), .name("vif"), .val(vif)
        ));
    endfunction

    virtual task run_phase(uvm_phase phase);
        drive();
    endtask

    virtual task drive();
        my_uvm_transaction tx;

        // Wait for reset pulse to complete (active-high)
        @(posedge vif.reset);
        @(negedge vif.reset);

        // Safe init
        vif.in_valid = 1'b0;
        vif.in_data  = '0;

        forever begin
            @(negedge vif.clock) begin
                vif.in_valid = 1'b0;

                if (vif.fifo_full == 1'b0) begin
                    seq_item_port.get_next_item(tx);

                    vif.in_data  = tx.in_data;
                    vif.in_valid = 1'b1;

                    seq_item_port.item_done();
                end else begin
                    vif.in_valid = 1'b0;
                    vif.in_data  = '0;
                end
            end
        end
    endtask

endclass
