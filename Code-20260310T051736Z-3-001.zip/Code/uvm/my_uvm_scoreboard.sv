import uvm_pkg::*;

`uvm_analysis_imp_decl(_output)
`uvm_analysis_imp_decl(_compare)

class my_uvm_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(my_uvm_scoreboard)

    uvm_analysis_export #(my_uvm_transaction) sb_export_output;
    uvm_analysis_export #(my_uvm_transaction) sb_export_compare;

    uvm_tlm_analysis_fifo #(my_uvm_transaction) output_fifo;
    uvm_tlm_analysis_fifo #(my_uvm_transaction) compare_fifo;

    my_uvm_transaction tx_out;
    my_uvm_transaction tx_cmp;

    int sample_count;
    int mismatch_count;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        tx_out         = new("tx_out");
        tx_cmp         = new("tx_cmp");
        sample_count   = 0;
        mismatch_count = 0;
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        sb_export_output  = new("sb_export_output",  this);
        sb_export_compare = new("sb_export_compare", this);
        output_fifo       = new("output_fifo",        this);
        compare_fifo      = new("compare_fifo",       this);
    endfunction

    virtual function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        sb_export_output.connect(output_fifo.analysis_export);
        sb_export_compare.connect(compare_fifo.analysis_export);
    endfunction

    virtual task run();
        forever begin
            output_fifo.get(tx_out);
            compare_fifo.get(tx_cmp);
            comparison();
        end
    endtask

    virtual function void comparison();
        if (tx_out.out_class !== tx_cmp.out_class) begin
            `uvm_info("SB_CMP_DUT", tx_out.sprint(), UVM_LOW);
            `uvm_info("SB_CMP_EXP", tx_cmp.sprint(), UVM_LOW);
            `uvm_error("SB_CLASS_MISMATCH",
                $sformatf("NN CLASS mismatch at inference %0d: expected=%0d  got=%0d  (val=%0d)",
                          sample_count, tx_cmp.out_class, tx_out.out_class, tx_out.out_val));
            mismatch_count++;
        end else begin
            `uvm_info("SB_MATCH",
                $sformatf("Inference %0d CORRECT: class=%0d  val=%0d",
                          sample_count, tx_out.out_class, tx_out.out_val),
                UVM_LOW);
        end

        sample_count++;
    endfunction

    virtual function void final_phase(uvm_phase phase);
        super.final_phase(phase);

        if (sample_count == 0) begin
            `uvm_warning("SB_FINAL", "No inferences compared (sample_count==0).")
        end else if (mismatch_count == 0) begin
            `uvm_info("SB_FINAL",
                $sformatf("NN verification PASSED (bit-true vs golden). Inferences=%0d",
                          sample_count),
                UVM_LOW);
        end else begin
            `uvm_error("SB_FINAL",
                $sformatf("NN verification FAILED. Inferences=%0d  mismatched=%0d",
                          sample_count, mismatch_count));
        end
    endfunction

endclass
