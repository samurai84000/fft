import uvm_pkg::*;

class my_uvm_monitor_output extends uvm_component;
    `uvm_component_utils(my_uvm_monitor_output)

    virtual my_uvm_if vif;
    uvm_analysis_port #(my_uvm_transaction) mon_ap_output;

    int out_dut_file;
    int unsigned sample_idx;

    function new(string name = "my_uvm_monitor_output", uvm_component parent = null);
        super.new(name, parent);
        mon_ap_output = new("mon_ap_output", this);
        sample_idx    = 0;
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        if (!uvm_resource_db#(virtual my_uvm_if)::read_by_name("ifs", "vif", vif, this))
            `uvm_fatal("NOVIF", "monitor_output: no vif")

        out_dut_file = $fopen(NN_OUT_DUT_NAME, "w");
        if (!out_dut_file)
            `uvm_warning("MON_OUT_BUILD", "Could not open DUT output dump file. Continuing without dump.")
    endfunction

    task run_phase(uvm_phase phase);
        my_uvm_transaction tx;

        // Wait for reset pulse to complete
        @(posedge vif.reset);
        @(negedge vif.reset);

        forever begin
            @(posedge vif.clock);

            if (vif.out_valid === 1'b1) begin
                tx = my_uvm_transaction::type_id::create(
                         $sformatf("tx_out_%0d", sample_idx), this);

                // out_class and out_val are registered — stable at this posedge
                tx.out_class = vif.out_class;
                tx.out_val   = vif.out_val;

                `uvm_info("MON_OUT",
                    $sformatf("Inference result: class=%0d  val=%0d",
                              tx.out_class, tx.out_val),
                    UVM_LOW);

                if (out_dut_file)
                    $fwrite(out_dut_file, "%0d\n", tx.out_class);

                mon_ap_output.write(tx);
                sample_idx++;
            end
        end
    endtask

    function void final_phase(uvm_phase phase);
        super.final_phase(phase);
        if (out_dut_file) $fclose(out_dut_file);
    endfunction

endclass


class my_uvm_monitor_compare extends uvm_component;
    `uvm_component_utils(my_uvm_monitor_compare)

    uvm_analysis_port #(my_uvm_transaction) mon_ap_compare;
    virtual my_uvm_if vif;

    int f_ref;

    function new(string name = "my_uvm_monitor_compare", uvm_component parent = null);
        super.new(name, parent);
        mon_ap_compare = new("mon_ap_compare", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);

        if (!uvm_resource_db#(virtual my_uvm_if)::read_by_name("ifs", "vif", vif, this))
            `uvm_fatal("NOVIF", "monitor_compare: no vif")

        f_ref = $fopen(NN_OUT_REF_NAME, "r");
        if (!f_ref)
            `uvm_fatal("MON_CMP_BUILD", $sformatf("Failed to open %s", NN_OUT_REF_NAME));
    endfunction

    task run_phase(uvm_phase phase);
        my_uvm_transaction tx;
        int r;
        int unsigned label;

        // Wait for reset pulse to complete
        @(posedge vif.reset);
        @(negedge vif.reset);

        for (int i = 0; i < N_SAMPLES; i++) begin
            tx = my_uvm_transaction::type_id::create(
                     $sformatf("tx_cmp_%0d", i), this);

            r = $fscanf(f_ref, "%d\n", label);
            if (r != 1)
                `uvm_fatal("MON_CMP_RUN",
                    $sformatf("Failed to read label %0d from %s", i, NN_OUT_REF_NAME));

            tx.out_class = label[3:0];
            tx.out_val   = '0;   // reference file has no activation value

            `uvm_info("MON_CMP",
                $sformatf("Expected class: %0d", tx.out_class),
                UVM_LOW);

            mon_ap_compare.write(tx);
        end
    endtask

    function void final_phase(uvm_phase phase);
        super.final_phase(phase);
        if (f_ref) $fclose(f_ref);
    endfunction

endclass
