import uvm_pkg::*;

class my_uvm_test extends uvm_test;

    `uvm_component_utils(my_uvm_test)

    my_uvm_env env;
    virtual my_uvm_if vif;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    virtual function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env = my_uvm_env::type_id::create(.name("env"), .parent(this));

        void'(uvm_resource_db#(virtual my_uvm_if)::read_by_name(
            .scope("ifs"), .name("vif"), .val(vif)
        ));
    endfunction

    virtual function void end_of_elaboration_phase(uvm_phase phase);
        uvm_top.print_topology();
    endfunction

    virtual task run_phase(uvm_phase phase);
        my_uvm_sequence seq;
        int cycles;

        phase.raise_objection(.obj(this));

        seq = my_uvm_sequence::type_id::create(.name("seq"), .contxt(get_full_name()));
        seq.start(env.agent.seqr);

        // Wait until scoreboard has compared all expected inferences (or timeout)
        cycles = 0;
        while ((env.sb.sample_count < N_SAMPLES) && (cycles < MAX_INFERENCE_CYCLES)) begin
            @(posedge vif.clock);
            cycles++;
        end

        if (env.sb.sample_count < N_SAMPLES) begin
            `uvm_error("TEST_TIMEOUT",
                $sformatf("Timeout after %0d cycles waiting for %0d NN inference(s). Got %0d.",
                          cycles, N_SAMPLES, env.sb.sample_count));
        end

        phase.drop_objection(.obj(this));
    endtask

endclass
