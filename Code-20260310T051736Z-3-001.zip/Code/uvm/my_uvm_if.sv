import uvm_pkg::*;

interface my_uvm_if;

    // Global
    logic clock;
    logic reset;      // active-high synchronous (matches all RTL modules)

    // neural_net_top inputs
    logic        in_valid;       // push one pixel word into the input FIFO
    logic [31:0] in_data;        // pixel value (Q0 integer, 0-255)
    logic        fifo_full;      // backpressure: DUT FIFO is full, hold writes

    // neural_net_top outputs
    logic [3:0]        out_class;   // predicted digit 0-9
    logic signed [31:0] out_val;    // max activation value (debug)
    logic              out_valid;   // one-cycle pulse: inference result is ready
    logic              busy;        // FSM is not IDLE (collecting or computing)

endinterface
