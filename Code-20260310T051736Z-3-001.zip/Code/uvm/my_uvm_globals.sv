`ifndef __GLOBALS__
`define __GLOBALS__

localparam string NN_IN_NAME      = "../neural_net/x_test.txt";
localparam string NN_OUT_REF_NAME = "../neural_net/y_test.txt";
localparam string NN_OUT_DUT_NAME = "nn_out_dut.txt";

localparam int NUM_INPUTS   = 784;
localparam int NUM_CLASSES  = 10;
localparam int N_SAMPLES    = 1;
localparam int BITS         = 14;
localparam int QUANT_VAL    = (1 << BITS);
localparam int IN_W         = 32;
localparam int OUT_W        = 4;
localparam int CLOCK_PERIOD = 10;

// 784 collect + 7861 L0 + 1 relu + 121 L1 + 1 relu + 1 argmax = 8769 cycles
localparam int MAX_INFERENCE_CYCLES = 9000;

`endif