import uvm_pkg::*;
import my_uvm_package::*;
`include "my_uvm_if.sv"
`timescale 1 ns / 1 ns

module my_uvm_tb;

    my_uvm_if vif();

    // ----------------------------------------------------------------
    // DUT: neural_net_top
    // Weights are now hardcoded in layer_0_rom.sv / layer_1_rom.sv.
    // No file path parameters needed.
    // ----------------------------------------------------------------
    neural_net_top #(
        .DATA_WIDTH  (32),
        .NUM_INPUTS  (784),
        .L0_SIZE     (10),
        .L1_SIZE     (10),
        .BITS        (14),
        .FIFO_DEPTH  (16)
    ) dut (
        .clk        (vif.clock),
        .reset      (vif.reset),
        .in_valid   (vif.in_valid),
        .in_data    (vif.in_data),
        .fifo_full  (vif.fifo_full),
        .out_class  (vif.out_class),
        .out_val    (vif.out_val),
        .out_valid  (vif.out_valid),
        .busy       (vif.busy)
    );

    // Register VIF so driver and monitors can retrieve it
    initial begin
        uvm_resource_db#(virtual my_uvm_if)::set(
            .scope("ifs"), .name("vif"), .val(vif)
        );
        run_test("my_uvm_test");
    end

    // ----------------------------------------------------------------
    // Reset sequence (active-high, synchronous)
    // Assert for one full clock cycle then release.
    // ----------------------------------------------------------------
    initial begin
        vif.clock    <= 1'b1;
        vif.reset    <= 1'b0;

        // Safe init of driven signals
        vif.in_valid <= 1'b0;
        vif.in_data  <= '0;

        @(posedge vif.clock);
        vif.reset <= 1'b1;
        @(posedge vif.clock);
        vif.reset <= 1'b0;
    end

    // Clock generation -- 100 MHz
    always #(CLOCK_PERIOD/2) vif.clock = ~vif.clock;

endmodule