module argmax #(
    parameter int DATA_WIDTH  = 32,  
    parameter int NUM_CLASSES = 10   
) (
    input  logic                             clk,
    input  logic                             reset,      

    // Control
    input  logic                             valid_in,   // input vector is valid

    // Data
    input  logic signed [DATA_WIDTH-1:0]     data_in  [0:NUM_CLASSES-1],
    output logic [$clog2(NUM_CLASSES)-1:0]   out_class,  // predicted class index
    output logic signed [DATA_WIDTH-1:0]     out_val,    // also return the max val for testing and debugging
    output logic                             valid_out
);

    // Combinational argmax scan
    logic [$clog2(NUM_CLASSES)-1:0]  max_idx_comb;
    logic signed [DATA_WIDTH-1:0]    max_val_comb;

    always_comb begin : p_argmax
        automatic logic signed [DATA_WIDTH-1:0]   max_val;
        automatic logic [$clog2(NUM_CLASSES)-1:0] max_idx;

        // Initialize with class 0 
        max_val = data_in[0];
        max_idx = '0;

        // Scan classes 1 through NUM_CLASSES-1
        for (int i = 1; i < NUM_CLASSES; i++) begin
            if (data_in[i] > max_val) begin
                max_val = data_in[i];
                max_idx = $clog2(NUM_CLASSES)'(unsigned'(i));
            end
        end

        max_val_comb = max_val;
        max_idx_comb = max_idx;
    end

    // Output register 
    always_ff @(posedge clk) begin : p_output_reg
        if (reset) begin
            out_class <= '0;
            out_val   <= '0;
            valid_out <= 1'b0;
        end else begin
            valid_out <= valid_in;
            if (valid_in) begin
                out_class <= max_idx_comb;
                out_val   <= max_val_comb;
            end
        end
    end

endmodule