module neuron #(
    parameter int DATA_WIDTH = 32,
    parameter int INPUT_SIZE = 784,
    parameter int BITS       = 14
) (
    input  logic                          clk,
    input  logic                          reset,

    input  logic                          start,       // combinational from layer
    input  logic signed [DATA_WIDTH-1:0]  bias,
    input  logic signed [DATA_WIDTH-1:0]  input_word,
    input  logic signed [DATA_WIDTH-1:0]  weight_word,

    output logic signed [DATA_WIDTH-1:0]  data_out,
    output logic                          done
);

    localparam int CNT_BITS = $clog2(INPUT_SIZE);

    typedef enum logic [1:0] { IDLE=2'b00, MAC=2'b01, FINISH=2'b10 } state_t;
    state_t state;

    logic [CNT_BITS-1:0]          cnt;
    logic signed [DATA_WIDTH-1:0] acc;

    always_ff @(posedge clk) begin : p_neuron
        if (reset) begin
            state    <= IDLE;
            cnt      <= '0;
            acc      <= '0;
            data_out <= '0;
            done     <= 1'b0;
        end else begin
            done <= 1'b0;

            case (state)

                IDLE: begin
                    if (start) begin
                        acc   <= bias;   // seed accumulator, no MAC yet
                        cnt   <= '0;
                        state <= MAC;
                    end
                end

                MAC: begin
                    // DSP block: acc += (input * weight) >> BITS
                    acc <= acc + DATA_WIDTH'(signed'(
                               (48'(signed'(input_word)) *
                                48'(signed'(weight_word))) >>> BITS));
                    cnt <= cnt + 1'b1;

                    if (cnt == CNT_BITS'(INPUT_SIZE - 1))
                        state <= FINISH;
                end

                FINISH: begin
                    data_out <= DATA_WIDTH'(signed'(acc >>> BITS));
                    done     <= 1'b1;
                    state    <= IDLE;
                end

                default: state <= IDLE;

            endcase
        end
    end

endmodule