module neural_net_top #(
    parameter int DATA_WIDTH = 32,
    parameter int NUM_INPUTS = 784,
    parameter int L0_SIZE    = 10,
    parameter int L1_SIZE    = 10,
    parameter int BITS       = 14,
    parameter int FIFO_DEPTH = 16
) (
    input  logic                               clk,
    input  logic                               reset,
    input  logic                               in_valid,
    input  logic [DATA_WIDTH-1:0]              in_data,
    output logic                               fifo_full,
    output logic [$clog2(L1_SIZE)-1:0]         out_class,
    output logic signed [DATA_WIDTH-1:0]       out_val,
    output logic                               out_valid,
    output logic                               busy
);


    // Input FIFO
    logic                  fifo_empty;
    logic                  fifo_rd_en;
    logic [DATA_WIDTH-1:0] fifo_dout;

    fifo #(
        .FIFO_DATA_WIDTH  (DATA_WIDTH),
        .FIFO_BUFFER_SIZE (FIFO_DEPTH)
    ) u_input_fifo (
        .reset  (reset),
        .wr_clk (clk), .wr_en (in_valid),   .din  (in_data),  .full  (fifo_full),
        .rd_clk (clk), .rd_en (fifo_rd_en), .dout (fifo_dout), .empty (fifo_empty)
    );


    // Input buffer
    logic signed [DATA_WIDTH-1:0] input_buf [0:NUM_INPUTS-1];

    // FSM
    typedef enum logic [1:0] { IDLE=2'b00, COLLECT=2'b01, COMPUTE=2'b10 } state_t;
    state_t                        state;
    logic [$clog2(NUM_INPUTS)-1:0] collect_cnt;
    logic                          l0_valid_in;

    assign busy       = (state != IDLE);
    assign fifo_rd_en = (state == COLLECT) && !fifo_empty;

    always_ff @(posedge clk) begin : p_fsm
        if (reset) begin
            state       <= IDLE;
            collect_cnt <= '0;
            l0_valid_in <= 1'b0;
        end else begin
            l0_valid_in <= 1'b0;
            case (state)
                IDLE: begin
                    collect_cnt <= '0;
                    if (!fifo_empty) state <= COLLECT;
                end
                COLLECT: begin
                    if (!fifo_empty) begin
                        input_buf[collect_cnt] <= signed'(fifo_dout);
                        if (collect_cnt == $clog2(NUM_INPUTS)'(NUM_INPUTS - 1)) begin
                            l0_valid_in <= 1'b1;
                            collect_cnt <= '0;
                            state       <= COMPUTE;
                        end else begin
                            collect_cnt <= collect_cnt + 1'b1;
                        end
                    end
                end
                COMPUTE: if (out_valid) state <= IDLE;
                default: state <= IDLE;
            endcase
        end
    end

    // Pipeline: layer0 -> relu -> layer1 -> relu -> argmax
    logic signed [DATA_WIDTH-1:0] l0_out [0:L0_SIZE-1]; logic l0_vld;
    logic signed [DATA_WIDTH-1:0] r0_out [0:L0_SIZE-1]; logic r0_vld;
    logic signed [DATA_WIDTH-1:0] l1_out [0:L1_SIZE-1]; logic l1_vld;
    logic signed [DATA_WIDTH-1:0] r1_out [0:L1_SIZE-1]; logic r1_vld;

    layer #(
        .INPUT_SIZE  (NUM_INPUTS),
        .OUTPUT_SIZE (L0_SIZE),
        .DATA_WIDTH  (DATA_WIDTH),
        .BITS        (BITS),
        .ROM_FILE    ("layer_0_weights_biases.txt")
    ) u_layer0 (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (l0_valid_in),
        .data_in   (input_buf),
        .data_out  (l0_out),
        .valid_out (l0_vld)
    );

    relu #(.DATA_WIDTH(DATA_WIDTH),.SIZE(L0_SIZE)) u_relu0
        (.clk(clk),.reset(reset),.valid_in(l0_vld),
         .data_in(l0_out),.data_out(r0_out),.valid_out(r0_vld));

    layer #(
        .INPUT_SIZE  (L0_SIZE),
        .OUTPUT_SIZE (L1_SIZE),
        .DATA_WIDTH  (DATA_WIDTH),
        .BITS        (BITS),
        .ROM_FILE    ("layer_1_weights_biases.txt")
    ) u_layer1 (
        .clk       (clk),
        .reset     (reset),
        .valid_in  (r0_vld),
        .data_in   (r0_out),
        .data_out  (l1_out),
        .valid_out (l1_vld)
    );

    relu #(.DATA_WIDTH(DATA_WIDTH),.SIZE(L1_SIZE)) u_relu1
        (.clk(clk),.reset(reset),.valid_in(l1_vld),
         .data_in(l1_out),.data_out(r1_out),.valid_out(r1_vld));

    argmax #(.DATA_WIDTH(DATA_WIDTH),.NUM_CLASSES(L1_SIZE)) u_argmax
        (.clk(clk),.reset(reset),.valid_in(r1_vld),
         .data_in(r1_out),.out_class(out_class),.out_val(out_val),.valid_out(out_valid));

endmodule