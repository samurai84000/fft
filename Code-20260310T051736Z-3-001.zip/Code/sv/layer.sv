module layer #(
    parameter int    INPUT_SIZE  = 784,
    parameter int    OUTPUT_SIZE = 10,
    parameter int    DATA_WIDTH  = 32,
    parameter int    BITS        = 14,   // Q14 fixed-point fractional bits
    parameter string ROM_FILE    = ""
) (
    input  logic                                      clk,
    input  logic                                      reset,
    input  logic                                      valid_in,
    input  logic signed [DATA_WIDTH-1:0]              data_in  [0:INPUT_SIZE-1],
    output logic signed [DATA_WIDTH-1:0]              data_out [0:OUTPUT_SIZE-1],
    output logic                                      valid_out
);
    // ROM layout: weights first (row-major, neuron j at j*INPUT_SIZE),
    // then biases appended at index NUM_WEIGHTS+j
    localparam int NUM_WEIGHTS = INPUT_SIZE * OUTPUT_SIZE;
    localparam int ROM_DEPTH   = NUM_WEIGHTS + OUTPUT_SIZE;
    localparam int W_BITS      = $clog2(INPUT_SIZE);   // bits to index one neuron's inputs
    localparam int N_BITS      = $clog2(OUTPUT_SIZE);  // bits to index neuron number
    localparam int A_BITS      = $clog2(ROM_DEPTH);    // bits to address the full ROM

    // Weights and biases loaded from file; inferred as a single M9K BRAM
    logic signed [DATA_WIDTH-1:0] rom [0:ROM_DEPTH-1];
    initial $readmemh(ROM_FILE, rom);

    // neuron_cnt: outer loop -- which output neuron is currently being computed
    // input_cnt:  inner loop -- which input element is being fed this cycle
    // flat_addr:  walks the ROM linearly; no multiply needed to find weight[j][i]
    logic [N_BITS-1:0] neuron_cnt;
    logic [W_BITS-1:0] input_cnt;
    logic [A_BITS-1:0] flat_addr;

    // One neuron instance is reused for all OUTPUT_SIZE computations sequentially
    typedef enum logic [1:0] { IDLE=2'b00, START=2'b01, RUN=2'b10, DONE=2'b11 } state_t;
    state_t state;

    logic                         n_start;
    logic signed [DATA_WIDTH-1:0] n_data_out;
    logic                         n_done;

    // n_start is combinational so the neuron sees it the same cycle the counters
    // sit at the base address -- no extra idle cycle wasted on handshake
    assign n_start = (state == START);

    // These are driven combinationally from the current counter values;
    // the neuron samples them on the rising edge during its MAC state
    logic signed [DATA_WIDTH-1:0] n_input_word;
    logic signed [DATA_WIDTH-1:0] n_weight_word;
    logic signed [DATA_WIDTH-1:0] n_bias;

    assign n_input_word  = data_in[input_cnt];
    assign n_weight_word = rom[flat_addr];
    assign n_bias        = rom[A_BITS'(NUM_WEIGHTS) + A_BITS'(neuron_cnt)]; // bias section starts after all weights

    // Single neuron 
    neuron #(
        .DATA_WIDTH (DATA_WIDTH),
        .INPUT_SIZE (INPUT_SIZE),
        .BITS       (BITS)
    ) u_neuron (
        .clk         (clk),
        .reset       (reset),
        .start       (n_start),
        .bias        (n_bias),
        .input_word  (n_input_word),
        .weight_word (n_weight_word),
        .data_out    (n_data_out),
        .done        (n_done)
    );

    // Results accumulate as each neuron finishes; held stable until next valid_in
    logic signed [DATA_WIDTH-1:0] out_buf [0:OUTPUT_SIZE-1];
    genvar k;
    generate
        for (k = 0; k < OUTPUT_SIZE; k++) begin : gen_out
            assign data_out[k] = out_buf[k];
        end
    endgenerate

    always_ff @(posedge clk) begin : p_layer
        if (reset) begin
            state      <= IDLE;
            neuron_cnt <= '0;
            input_cnt  <= '0;
            flat_addr  <= '0;
            valid_out  <= 1'b0;
            for (int k = 0; k < OUTPUT_SIZE; k++)
                out_buf[k] <= '0;
        end else begin
            valid_out <= 1'b0; // default low; only pulses for one cycle in DONE

            case (state)

                IDLE: begin
                    // Wait for upstream to present a full input vector
                    if (valid_in) begin
                        neuron_cnt <= '0;
                        input_cnt  <= '0;
                        flat_addr  <= '0;
                        state      <= START;
                    end
                end

                START: begin
                    // n_start fires combinationally this cycle; neuron loads bias
                    // into its accumulator and moves to MAC on the next edge.
                    // Counters stay at base so RUN begins feeding from index 0.
                    state <= RUN;
                end

                RUN: begin
                    if (n_done) begin
                        // Neuron's FINISH state caused one extra counter advance
                        // last cycle. Subtract 1 from flat_addr to land exactly
                        // at (neuron_cnt+1)*INPUT_SIZE, the next neuron's weight base.
                        out_buf[neuron_cnt] <= n_data_out;
                        flat_addr           <= flat_addr - 1'b1;
                        input_cnt           <= '0; // reset inner loop for next neuron

                        if (neuron_cnt == N_BITS'(OUTPUT_SIZE - 1)) begin
                            state <= DONE; // all output neurons computed
                        end else begin
                            neuron_cnt <= neuron_cnt + 1'b1;
                            state      <= START; // kick off next neuron
                        end
                    end else begin
                        // Normal MAC cycle: advance both counters together so
                        // the neuron always sees input[i] paired with weight[j*N+i]
                        input_cnt <= input_cnt + 1'b1;
                        flat_addr <= flat_addr + 1'b1;
                    end
                end

                DONE: begin
                    // All outputs are valid in out_buf; pulse valid_out for one cycle
                    valid_out <= 1'b1;
                    state     <= IDLE;
                end

                default: state <= IDLE;

            endcase
        end
    end

endmodule