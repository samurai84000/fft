module relu #(
    parameter int DATA_WIDTH = 32,  
    parameter int SIZE       = 10   // number of elements (matches layer OUTPUT_SIZE)
) (
    input  logic                             clk,
    input  logic                             reset,     

    // Control
    input  logic                             valid_in,  // input vector is valid

    // Data
    input  logic signed [DATA_WIDTH-1:0]     data_in  [0:SIZE-1],
    output logic signed [DATA_WIDTH-1:0]     data_out [0:SIZE-1],
    output logic                             valid_out
);


    // Output register
    always_ff @(posedge clk) begin : p_relu
        if (reset) begin
            for (int i = 0; i < SIZE; i++)
                data_out[i] <= '0;
            valid_out <= 1'b0;
        end else begin
            valid_out <= valid_in;
            if (valid_in) begin
                for (int i = 0; i < SIZE; i++)
                    data_out[i] <= (data_in[i] > 0) ? data_in[i] : '0;
            end
        end
    end

endmodule