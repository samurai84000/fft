# nn_sim.do  (Questa/ModelSim)
# Place in: ~/ece387/Assignments/HW8/sim/
# Run from sim/:  do nn_sim.do

setenv LMC_TIMEUNIT -9

vlib work
vmap work work

# ============================================================
# RTL (Neural Network) -- compile bottom-up (no forward refs)
# ============================================================
vlog -sv -work work "../sv/fifo.sv"
vlog -sv -work work "../sv/neuron.sv"
vlog -sv -work work "../sv/layer.sv"
vlog -sv -work work "../sv/relu.sv"
vlog -sv -work work "../sv/argmax.sv"
vlog -sv -work work "../sv/neural_net_top.sv"

# ============================================================
# UVM library (disable DPI)
# ============================================================
vlog -sv -work work +define+UVM_NO_DPI +incdir+$env(UVM_HOME)/src  $env(UVM_HOME)/src/uvm.sv
vlog -sv -work work +define+UVM_NO_DPI +incdir+$env(UVM_HOME)/src  $env(UVM_HOME)/src/uvm_macros.svh
vlog -sv -work work +define+UVM_NO_DPI +incdir+$env(UVM_HOME)/src  \
  $env(MTI_HOME)/verilog_src/questa_uvm_pkg-1.2/src/questa_uvm_pkg.sv

# ============================================================
# UVM testbench files
# ============================================================
vlog -sv -work work +incdir+../uvm "../uvm/my_uvm_if.sv"
vlog -sv -work work +incdir+$env(UVM_HOME)/src +incdir+../uvm "../uvm/my_uvm_globals.sv"
vlog -sv -work work +incdir+$env(UVM_HOME)/src +incdir+../uvm "../uvm/my_uvm_pkg.sv"
vlog -sv -work work +incdir+$env(UVM_HOME)/src +incdir+../uvm "../uvm/my_uvm_tb.sv"

# ============================================================
# Start sim
# ============================================================
vsim -classdebug -voptargs=+acc +notimingchecks -L work work.my_uvm_tb \
  -wlf nn_sim.wlf \
  -dpicpppath /usr/bin/gcc

# ============================================================
# GUARANTEE waveform logging (so WLF has data even in batch mode)
# ============================================================
log -r /*

# Try to open wave window (harmless in batch)
catch {view wave}
catch {view structure}
catch {view signals}

# ============================================================
# Toggle: set to 1 for internal pipeline signals
# ============================================================
set DEEP_DEBUG 0

# ============================================================
# Helpers (identical pattern to fft_sim.do)
# ============================================================
proc try_add_wave {radix path} {
  if {[catch {add wave -noupdate -radix $radix $path} err]} {
    return 0
  } else {
    return 1
  }
}

# ============================================================
# Minimal waves: interface + FSM + pipeline valid chain
# These are the signals you need to debug 99% of problems:
#   - Did the driver push pixels correctly?
#   - Did the FSM collect all 784 and fire?
#   - Did valid propagate through all 5 pipeline stages?
#   - Did out_valid pulse and out_class look right?
# ============================================================
proc add_minimal_waves {} {
  set dut sim:/my_uvm_tb/dut

  add wave -noupdate -divider "TB / Interface"
  try_add_wave unsigned sim:/my_uvm_tb/vif/clock
  try_add_wave unsigned sim:/my_uvm_tb/vif/reset

  add wave -noupdate -divider "TB->DUT (pixel stream)"
  try_add_wave unsigned sim:/my_uvm_tb/vif/in_valid
  try_add_wave unsigned sim:/my_uvm_tb/vif/fifo_full
  try_add_wave hex      sim:/my_uvm_tb/vif/in_data

  add wave -noupdate -divider "DUT->TB (inference result)"
  try_add_wave unsigned sim:/my_uvm_tb/vif/out_valid
  try_add_wave unsigned sim:/my_uvm_tb/vif/busy
  try_add_wave unsigned sim:/my_uvm_tb/vif/out_class
  try_add_wave decimal  sim:/my_uvm_tb/vif/out_val

  add wave -noupdate -divider "Collector FSM"
  try_add_wave unsigned $dut/state
  try_add_wave unsigned $dut/collect_cnt
  try_add_wave unsigned $dut/l0_valid_in
  try_add_wave unsigned $dut/fifo_empty
  try_add_wave unsigned $dut/fifo_rd_en

  add wave -noupdate -divider "Pipeline valid chain"
  try_add_wave unsigned $dut/l0_valid_out
  try_add_wave unsigned $dut/relu0_valid_out
  try_add_wave unsigned $dut/l1_valid_out
  try_add_wave unsigned $dut/relu1_valid_out
  try_add_wave unsigned $dut/vif/out_valid
}

# ============================================================
# Deep debug: layer outputs and argmax inputs
# Enable with DEEP_DEBUG 1
# ============================================================
proc add_deep_debug_waves {} {
  set dut sim:/my_uvm_tb/dut

  add wave -noupdate -divider "DEEP: Layer 0 outputs (all 10 neurons)"
  for {set i 0} {$i < 10} {incr i} {
    try_add_wave decimal $dut/l0_data_out($i)
  }

  add wave -noupdate -divider "DEEP: ReLU 0 outputs"
  for {set i 0} {$i < 10} {incr i} {
    try_add_wave decimal $dut/relu0_data_out($i)
  }

  add wave -noupdate -divider "DEEP: Layer 1 outputs (all 10 neurons)"
  for {set i 0} {$i < 10} {incr i} {
    try_add_wave decimal $dut/l1_data_out($i)
  }

  add wave -noupdate -divider "DEEP: ReLU 1 outputs (argmax inputs)"
  for {set i 0} {$i < 10} {incr i} {
    try_add_wave decimal $dut/relu1_data_out($i)
  }

  add wave -noupdate -divider "DEEP: Input buffer (first 8 pixels)"
  for {set i 0} {$i < 8} {incr i} {
    try_add_wave hex $dut/input_buf($i)
  }
}

# ============================================================
# Wave setup
# ============================================================
delete wave *
add_minimal_waves
if {$DEEP_DEBUG} { add_deep_debug_waves }

update
run -all

catch {wave zoom full}
